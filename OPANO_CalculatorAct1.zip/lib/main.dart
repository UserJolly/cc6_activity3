import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expression = '';
  double _result = 0.0;
  Operator _selectedOperator = Operator.None;
  double _previousValue = 0.0;

  void _onButtonPressed(String buttonText) {
    setState(() {
      if (buttonText == '=') {
        try {
          double currentValue = double.parse(_expression);

          switch (_selectedOperator) {
            case Operator.Addition:
              _result = _previousValue + currentValue;
              break;
            case Operator.Subtraction:
              _result = _previousValue - currentValue;
              break;
            case Operator.Multiplication:
              _result = _previousValue * currentValue;
              break;
            case Operator.Division:
              _result = _previousValue / currentValue;
              break;
            case Operator.None:
              _result = currentValue;
              break;
          }

          _expression = _result.toString();
        } catch (e) {
          _expression = 'Error';
        }

        _selectedOperator = Operator.None;
      } else if (buttonText == 'C') {
        _expression = '';
        _selectedOperator = Operator.None;
      } else if (buttonText == '+' ||
          buttonText == '-' ||
          buttonText == 'x' ||
          buttonText == '÷') {
        _selectedOperator = getOperatorFromButton(buttonText);
        _previousValue = double.parse(_expression);
        _expression = '';
      } else {
        _expression += buttonText;
      }
    });
  }

  Operator getOperatorFromButton(String buttonText) {
    switch (buttonText) {
      case '+':
        return Operator.Addition;
      case '-':
        return Operator.Subtraction;
      case 'x':
        return Operator.Multiplication;
      case '÷':
        return Operator.Division;
      default:
        return Operator.None;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16.0),
              alignment: Alignment.bottomRight,
              child: Text(
                _expression,
                style: TextStyle(fontSize: 48.0, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Divider(height: 1.0),
          Expanded(
            flex: 2,
            child: GridView.builder(
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 1.0,
                mainAxisSpacing: 1.0,
              ),
              itemCount: buttonLabels.length,
              itemBuilder: (context, index) {
                return CalculatorButton(
                  label: buttonLabels[index],
                  onPressed: () => _onButtonPressed(buttonLabels[index]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CalculatorButton extends StatelessWidget {
  final String label;
  final Function onPressed;

  CalculatorButton({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(4.0),
      child: TextButton(
        onPressed: () => onPressed(),
        child: Text(
          label,
          style: TextStyle(fontSize: 24.0),
        ),
        style: ButtonStyle(
          padding: MaterialStateProperty.all<EdgeInsets>(EdgeInsets.all(16.0)),
          backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
          foregroundColor: MaterialStateProperty.all<Color>(Colors.black),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
          ),
        ),
      ),
    );
  }
}

const List<String> buttonLabels = [
  '7',
  '8',
  '9',
  '÷',
  '4',
  '5',
  '6',
  'x',
  '1',
  '2',
  '3',
  '-',
  '0',
  '.',
  '=',
  '+',
  'C',
];

enum Operator {
  None,
  Addition,
  Subtraction,
  Multiplication,
  Division,
}
