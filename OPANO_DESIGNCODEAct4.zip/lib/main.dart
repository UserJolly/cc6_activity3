import 'package:flutter/material.dart';
import 'login_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dive In Button',
      theme: ThemeData(
        primaryColor: Color(0xFF458CF6), // Background color
      ),
      home: MainPage(),
    );
  }
}

class MainPage extends StatelessWidget {
  void _navigateToLoginPage(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dive In Button'),
      ),
      backgroundColor: Color(0xFF458CF6), // Screen color
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 200,
            height: 200, // Adjust the width and height as needed
            child: Image.asset(
              'assets/images/Blue-Whale-logo.png', // Replace with your image path
            ),
          ),
          SizedBox(height: 20),
          Container(
            width: double.infinity,
            height: 150,
            decoration: BoxDecoration(
              color: Color(0xFF00A3FF), // Rectangle color
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Text(
                'Welcome to BLUEWHALE!\nWhere the Ocean meets the Sky\nand the Sky meets the Sea!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white, // Text color
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => _navigateToLoginPage(context),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(
                  vertical: 28, horizontal: 50), // Adjusted button size
              primary: Color(0xFF7B98FF), // Button color
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20), // Corner radius
                side: BorderSide(width: 1, color: Colors.black), // Border
              ),
            ),
            child: Text(
              'Dive In',
              style: TextStyle(fontSize: 25), // Increased font size
            ),
          ),
        ],
      ),
    );
  }
}
