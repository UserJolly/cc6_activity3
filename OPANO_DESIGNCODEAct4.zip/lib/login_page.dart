import 'package:flutter/material.dart';
import 'signup_page.dart';
import 'fact_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _verifyPasswordController =
      TextEditingController(); // Add this line

  void _login(BuildContext context) {
    String email = _emailController.text;
    String password = _passwordController.text;
    bool isEmailValid = false;
    bool isPasswordValid = false;

    if (email.isNotEmpty) {
      if (email.contains('@')) {
        isEmailValid = true;
      } else {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Error'),
            content: Text('Unknown Email'),
            actions: [
              TextButton(
                child: Text('OK'),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      }
    }

    if (password.isNotEmpty) {
      // Always consider the password as valid
      isPasswordValid = true;
    }

    if (isEmailValid && isPasswordValid) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => FactPage()),
      );
    }
  }

  void _signup(BuildContext context) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => SignupPage(
                emailController: _emailController,
                passwordController: _passwordController,
                verifyPasswordController: _verifyPasswordController,
              )),
    );

    if (result != null && result is Map<String, String>) {
      String name = result['name'] ?? '';
      String email = result['email'] ?? '';
      String password = result['password'] ?? '';

      // Use the retrieved data as needed
      print('Name: $name');
      print('Email: $email');
      print('Password: $password');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      backgroundColor: Color(0xFF0DF0FF), // Updated screen background color
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/Blue-Whale-logo.png',
                fit: BoxFit.cover,
              ),
            ),
            Center(
              child: Container(
                width: 300,
                height: 400,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    color: Color(0xFF8BA2F3),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Align(
                          alignment: AlignmentDirectional.topStart,
                          child: Text(
                            'Email:',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          width: double
                              .infinity, // Set the width to occupy the entire available space
                          child: TextField(
                            controller: _emailController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              labelText: 'Email',
                              filled: true, // Enable filling with color
                              fillColor: Colors.white, // Set background color
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                    20), // Set border radius
                                borderSide: BorderSide(
                                  color: Colors.black,
                                  width: 3.0,
                                ),
                              ),
                            ),
                            style: TextStyle(color: Colors.black), // Text color
                          ),
                        ),
                      ),
                      SizedBox(height: 16.0),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Align(
                          alignment: AlignmentDirectional.topStart,
                          child: Text(
                            'Password:',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          width: double
                              .infinity, // Set the width to occupy the entire available space
                          child: TextField(
                            controller: _passwordController,
                            obscureText: true,
                            decoration: InputDecoration(
                              labelText: 'Password',
                              filled: true, // Enable filling with color
                              fillColor: Colors.white, // Set background color
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                    20), // Set border radius
                                borderSide: BorderSide(
                                  color: Colors.black,
                                  width: 3.0,
                                ),
                              ),
                            ),
                            style: TextStyle(color: Colors.black), // Text color
                          ),
                        ),
                      ),
                      SizedBox(height: 24.0),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: ElevatedButton(
                          onPressed: () => _login(context),
                          style: ElevatedButton.styleFrom(
                            primary: Color(0xFF2351F5), // Button color
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  30), // Button border radius
                            ),
                            padding: EdgeInsets.symmetric(
                              horizontal: 40, // Horizontal padding
                              vertical: 12, // Vertical padding
                            ),
                          ),
                          child: Text(
                            'Login',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                      SizedBox(height: 16.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Don't have an Account? ",
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          TextButton(
                            onPressed: () => _signup(context),
                            child: Text(
                              'Signup',
                              style: TextStyle(
                                color: Color(0xFF076CC9),
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ], // Closing parenthesis for the children list
        ),
      ),
    );
  }
}
