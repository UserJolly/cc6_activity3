package com.example.designcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
